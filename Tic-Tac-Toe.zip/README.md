# Tie Tac Toe

A simple PvP game of Tic-Tac-Toe (Noughts and Crosses) with features suc as - 

Wins counter for each team 
'Game Restart' and 'Wins Counter Reset' buttons 
Pleasent formatting, animations and colours 

## Features to come 

### Play VS A.I.
Buttons to switch between PvP and play VS A.I.
Two A.I. dificulty modes (easy and hard) 